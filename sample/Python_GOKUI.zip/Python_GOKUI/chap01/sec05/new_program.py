num = 100*2
print(num)


