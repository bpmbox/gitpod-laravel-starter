print('入力された数値を合計します')
num1 = input('1番目の値を入力してください>')
num2 = input('2番目の値を入力してください>')
num3 = input('3番目の値を入力してください>')
result = num1 + num2 + num3
print('合計は' +  str(int(num1) + int(num2) + int(num3)))
