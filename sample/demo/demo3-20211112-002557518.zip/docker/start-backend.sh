#!/usr/bin/env bash
yarn reset
yarn start:dev
