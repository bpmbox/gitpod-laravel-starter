import React from 'react';
import TagsTable from 'pages/CRUD/Tags/table/TagsTable';

const TagsTablePage = () => {
  return (
    <div>
      <TagsTable />
    </div>
  );
}

export default TagsTablePage;
