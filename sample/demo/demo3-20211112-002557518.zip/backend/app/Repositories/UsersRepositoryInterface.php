<?php

namespace App\Repositories;

use Illuminate\Support\Collection;

interface UsersRepositoryInterface extends EloquentRepositoryInterface
{

}

    
