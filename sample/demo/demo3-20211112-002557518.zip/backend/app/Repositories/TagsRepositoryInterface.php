<?php

namespace App\Repositories;

use Illuminate\Support\Collection;

interface TagsRepositoryInterface extends EloquentRepositoryInterface
{

}

    
